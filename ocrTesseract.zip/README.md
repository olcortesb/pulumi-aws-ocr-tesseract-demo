# ocr_tesserac_lambda

|Language/system|Version|
|-|-|
|nvm| 0.38.0 |
|nodejs| v14.x |
|serverless| Framework Core: 2.32.1
       Plugin: 4.5.3
       SDK: 4.2.2
       Components: 3.8.1 |


## Install NodeJS
### MacOs:

`brew install node` Install Node.
`node -v`Check node version installed
`npm -v` Check npm version installed

## Install NVM

`curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.38.0/install.sh | bash`

The script clones the nvm repository to ~/.nvm, and attempts to add the source lines from the snippet below to the correct profile file (~/.bash_profile, ~/.zshrc, ~/.profile, or ~/.bashrc).
```
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"  # This loads nvm
[ -s "$NVM_DIR/bash_completion" ] && \. "$NVM_DIR/bash_completion"  # This loads nvm bash_completion
```
More info: https://github.com/nvm-sh/nvm#install--update-script

Commands:
`nvm list` Node version installed
`nvm ls-remote` Show node versions witch can be installed
`nvm install v14.16.0` Install version nodejs, in this case node 14.16.0. You can show all of them with last command.
`nvm use v14.16.0` Set a version as current version

## Install serverless framework

Installing:

`npm install -g serverless`


Commands:

If you need add to `~/.aws/credentials` a new profile, you can do it as (https://www.serverless.com/framework/docs/providers/aws/guide/credentials#setup-with-serverless-config-credentials-command):
`serverless config credentials --provider aws --profile PROFILE_USER_LAMBDA --key KEY --secret SECRET`

Run and test locally:
`serverless invoke local --function solveCaptcha --data '{"img":"https://images-na.ssl-images-amazon.com/captcha/xjgkhgck/Captcha_xiaixbadtl.jpg"}'`

Deploy lambda:
`serverless deploy --stage dev --aws-profile default`
_aws-profile default is a default profile created first time you create `~/.aws/credentials`_


## Run proyect

1. `git clone git@github.com:BufeteMkt/ocr_tesserac_lambda.git`
2. Install nvm, nodejs, serverless
3. `npm install`
4. Try to execute locally the function: `serverless invoke local --function solveCaptcha --data '{"img":"https://images-na.ssl-images-amazon.com/captcha/xjgkhgck/Captcha_xiaixbadtl.jpg"}'`




