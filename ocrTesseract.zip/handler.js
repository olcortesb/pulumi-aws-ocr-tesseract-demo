'use strict';

const Jimp = require("jimp");
const path = require('path');
const fs = require('fs');
const { createWorker } = require('tesseract.js');

module.exports.solveCaptcha = async (event) => {
  var img;
  if (event.img) {
    img = event.img;
  } else {
    const body = JSON.parse(event.body);
    img = body.img;
  }

  const imageData = await getImageFormat(img);

  if (imageData == null || imageData == '') {
    return sendResponse(400, 'Imagen cannot be null');
  }

  try {
    const processedImage = await processImage(imageData);
                          
    const result = await solveCaptchaImage(processedImage)
                          .then(text => { return text; })
                          .catch(err => { throw err; })

    return sendResponse(200, { text: result.trim() });
  } catch (err) {
    return sendResponse(500, { error: err.toString() });
  }
};

const processImage = (image) => {
  return Jimp.read(image)
    .then(img => {
      let newImage;

      img
        .color([{apply: 'desaturate', params: [90]}])
        .contrast(1)
        .getBase64(Jimp.AUTO, function (err, src) {
          newImage = src;
        });

      return newImage;
    })
    .catch(err => { throw err; });
}

const solveCaptchaImage = (image) => {
  return new Promise(async (resolve, reject) => {
    const dir = path.join('/tmp');
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir);
    }

    const worker = createWorker({
      cachePath: path.join('/tmp'),
      langPath: path.join(__dirname, 'lang-data')
    });

    await worker.load();
    await worker.loadLanguage('eng');
    await worker.initialize('eng');

    const { data: { text } } = await worker.recognize(image);

    await worker.terminate();
    resolve(text);
  });
}

// image format to be process by JIMP library.
// @return [String|null] => if image is base64, we delete header, else if image is an image url return url, otherwise return null value
const getImageFormat = (image) => {
  if (isDataUrlImage(image)) {
    return Buffer.from(image.replace(/^data:image\/(png|jpg|jpeg|gif);base64,/, ""), 'base64');
  } else if (isURLImage(image)) {
    return image;
  } else {
    return null;
  }
}

// @return [true|false] => true if image is base64 format, otherwise false
const isDataUrlImage = (img) => {
  return !!img.match(/^\s*data:([a-z]+\/[a-z]+(;[a-z\-]+\=[a-z\-]+)?)?(;base64)?,[a-z0-9\!\$\&\'\,\(\)\*\+\,\;\=\-\.\_\~\:\@\/\?\%\s]*\s*$/i);
}

// @return [true|false] => true if image url is well formed, otherwise false
const isURLImage = (img) => {
  return !!img.match(/\.(jpeg|jpg|gif|png)$/);
}

// @return [Hash/map] => Return structure response with data passed by params.
const sendResponse = (statusCode, message) => {
  return {
    statusCode: statusCode,
    body: JSON.stringify(message)
  }
}
